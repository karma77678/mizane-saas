import { Router, type IRouter } from "express";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();
router.use(requireAuth);
router.use(rateLimit({ windowMs: 60_000, limit: 5, standardHeaders: true, legacyHeaders: false }));

const correctionSchema = {
  type: "object",
  properties: {
    description: { type: "string" },
    journalEntry: {
      type: "array",
      maxItems: 8,
      items: {
        type: "object",
        properties: {
          accountCode: { type: "string" },
          accountLabel: { type: "string" },
          debit: { type: "number" },
          credit: { type: "number" },
          rationale: { type: "string" },
        },
        required: ["accountCode", "accountLabel", "debit", "credit", "rationale"],
        additionalProperties: false,
      },
    },
    prerequisites: { type: "array", maxItems: 8, items: { type: "string" } },
    confidence: { type: "string", enum: ["faible", "moyenne", "élevée"] },
    disclaimer: { type: "string" },
  },
  required: ["description", "journalEntry", "prerequisites", "confidence", "disclaimer"],
  additionalProperties: false,
} as const;

router.post("/audit/ai-correction", async (req, res): Promise<void> => {
  const fetchSite = req.get("sec-fetch-site");
  const allowedOrigin = process.env.APP_ORIGIN?.trim().replace(/\/$/, "");
  if (fetchSite === "cross-site" && (!allowedOrigin || req.get("origin") !== allowedOrigin)) {
    res.status(403).json({ error: "La proposition IA doit être demandée depuis l’application autorisée." });
    return;
  }
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) { res.status(503).json({ error: "L’IA n’est pas configurée. Ajoutez OPENAI_API_KEY dans les Secrets du projet." }); return; }
  const finding = req.body?.finding;
  const rows = Array.isArray(req.body?.sourceRows) ? req.body.sourceRows : [];
  if (!finding || typeof finding !== "object" || rows.length > 50) { res.status(400).json({ error: "Le constat ou les lignes sources ne sont pas valides." }); return; }
  const cleanText = (value: unknown, max = 2000) => typeof value === "string" ? value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, " ").slice(0, max) : "";
  const input = {
    ruleCode: cleanText(finding.ruleCode, 80),
    severity: cleanText(finding.severity, 20),
    title: cleanText(finding.title, 300),
    explanation: cleanText(finding.explanation, 3000),
    amount: Number.isFinite(Number(finding.amount)) ? Number(finding.amount) : 0,
    suggestion: cleanText(finding.suggestion, 3000),
    sourceRows: rows.map((row: any) => ({
      date: cleanText(row.date, 50),
      accountCode: cleanText(row.accountCode, 60),
      accountLabel: cleanText(row.accountLabel, 180),
      reference: cleanText(row.reference, 160),
      description: cleanText(row.description, 500),
      debit: Number.isFinite(Number(row.debit)) ? Number(row.debit) : 0,
      credit: Number.isFinite(Number(row.credit)) ? Number(row.credit) : 0,
    })),
  };
  try {
    const client = new OpenAI({ apiKey });
    const result = await client.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 2500,
      response_format: { type: "json_schema", json_schema: { name: "mizan_accounting_correction", strict: true, schema: correctionSchema } },
      messages: [
        {
          role: "system",
          content: "Tu es un assistant d'audit comptable marocain. Propose une écriture de régularisation uniquement comme brouillon à faire vérifier. Ne certifie jamais la conformité et n'invente pas de données manquantes, de textes légaux ou de pièces. Si les données sont insuffisantes, explique-le dans prerequisites et utilise des montants à zéro ou un journalEntry vide plutôt que d'inventer une écriture chiffrée. Les débits et crédits proposés doivent être non négatifs et équilibrés quand une écriture est réellement justifiable à partir des éléments fournis. Ne dis jamais qu'une correction a été appliquée.",
        },
        { role: "user", content: JSON.stringify(input) },
      ],
    });
    const content = result.choices[0]?.message.content;
    if (!content) { res.status(503).json({ error: "La réponse IA est vide." }); return; }
    const decoded = JSON.parse(content) as unknown;
    if (!decoded || typeof decoded !== "object" || Array.isArray(decoded)) {
      res.status(503).json({ error: "Réponse IA invalide." });
      return;
    }

    // Never display an unbalanced/invalid generated journal entry as a usable draft.
    const proposal = decoded as Record<string, unknown>;
    const rawLines = Array.isArray(proposal.journalEntry) ? proposal.journalEntry : [];
    const journalLines = rawLines.filter((line): line is Record<string, unknown> =>
      Boolean(line) && typeof line === "object" && !Array.isArray(line),
    );
    const valuesAreValid = journalLines.length === rawLines.length && journalLines.every((line) =>
      typeof line.debit === "number" && Number.isFinite(line.debit) && line.debit >= 0 &&
      typeof line.credit === "number" && Number.isFinite(line.credit) && line.credit >= 0,
    );
    const totalDebit = valuesAreValid ? journalLines.reduce((sum, line) => sum + Number(line.debit), 0) : 0;
    const totalCredit = valuesAreValid ? journalLines.reduce((sum, line) => sum + Number(line.credit), 0) : 0;
    const balanced = journalLines.length === 0 || Math.abs(totalDebit - totalCredit) <= 0.01;
    if (!valuesAreValid || !balanced) {
      proposal.journalEntry = [];
      proposal.confidence = "faible";
      const prerequisites = Array.isArray(proposal.prerequisites)
        ? proposal.prerequisites.filter((item): item is string => typeof item === "string")
        : [];
      proposal.prerequisites = [
        ...prerequisites,
        "L’écriture générée n’a pas passé le contrôle automatique de cohérence des montants ; aucune écriture n’est proposée. Faites vérifier les pièces et les soldes par un professionnel.",
      ].slice(0, 8);
      proposal.disclaimer = typeof proposal.disclaimer === "string" ? proposal.disclaimer : "Proposition indicative à faire vérifier.";
    }
    res.json(proposal);
  } catch (error) {
    req.log.error({ error: error instanceof Error ? error.message : "Unknown AI provider error" }, "AI correction proposal failed");
    res.status(503).json({ error: "Impossible de générer une proposition pour le moment." });
  }
});

export default router;
