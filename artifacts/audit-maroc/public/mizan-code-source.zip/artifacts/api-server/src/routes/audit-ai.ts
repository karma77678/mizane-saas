import { Router, type IRouter } from "express";
import { requireAuth } from "../middlewares/auth";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import {
  ReviewAuditWithAiBody,
  ReviewAuditWithAiResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
router.use(requireAuth);

const aiRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 6,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Limite d’analyses IA atteinte. Réessayez dans une minute." },
});
const DAILY_REVIEW_LIMIT = 60;
let dailyReviewCount = 0;
let dailyReviewDate = new Date().toISOString().slice(0, 10);

function consumeDailyReviewQuota(): boolean {
  const today = new Date().toISOString().slice(0, 10);
  if (today !== dailyReviewDate) {
    dailyReviewDate = today;
    dailyReviewCount = 0;
  }
  if (dailyReviewCount >= DAILY_REVIEW_LIMIT) return false;
  dailyReviewCount += 1;
  return true;
}

const outputSchema = {
  type: "object",
  properties: {
    executiveSummary: { type: "string" },
    priorities: {
      type: "array",
      maxItems: 6,
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          explanation: { type: "string" },
          suggestedAction: { type: "string" },
          severity: {
            type: "string",
            enum: ["critical", "high", "medium", "low", "info"],
          },
          relatedRuleCodes: { type: "array", items: { type: "string" } },
        },
        required: [
          "title",
          "explanation",
          "suggestedAction",
          "severity",
          "relatedRuleCodes",
        ],
        additionalProperties: false,
      },
    },
    limitations: { type: "string" },
  },
  required: ["executiveSummary", "priorities", "limitations"],
  additionalProperties: false,
} as const;

router.post("/audit/ai-review", aiRateLimit, async (req, res): Promise<void> => {
  const fetchSite = req.get("sec-fetch-site");
  const allowedOrigin = process.env.APP_ORIGIN?.trim().replace(/\/$/, "");
  if (fetchSite === "cross-site" && (!allowedOrigin || req.get("origin") !== allowedOrigin)) {
    res.status(403).json({ error: "La revue IA doit être demandée depuis l’application autorisée." });
    return;
  }

  const parsed = ReviewAuditWithAiBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn(
      { validationError: parsed.error.message },
      "Rejected invalid audit AI review request",
    );
    res.status(400).json({ error: "Les données agrégées sont invalides." });
    return;
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    res.status(503).json({
      error: "L’analyse IA n’est pas configurée. Les contrôles mathématiques restent disponibles.",
    });
    return;
  }
  if (!consumeDailyReviewQuota()) {
    res.status(429).json({
      error: "La limite quotidienne de revues IA est atteinte. Les contrôles locaux restent disponibles.",
    });
    return;
  }

  const { fiscalYear, summary, findings } = parsed.data;
  const sanitizedFindings = findings.map((finding) => ({
    ruleCode: /^[A-Z0-9_-]{1,80}$/.test(finding.ruleCode)
      ? finding.ruleCode
      : "UNKNOWN",
    severity: finding.severity,
    occurrences: finding.occurrences,
  }));
  const input = {
    fiscalYear,
    summary,
    findings: sanitizedFindings,
  };

  try {
    const client = new OpenAI({ apiKey });
    const result = await client.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "moroccan_accounting_audit_review",
          strict: true,
          schema: outputSchema,
        },
      },
      messages: [
        {
          role: "system",
          content:
            "Tu es un assistant pédagogique d’audit comptable travaillant sur des constats agrégés pour une entreprise marocaine. Explique et hiérarchise les risques à partir des seuls chiffres et codes fournis. Ne prétends pas certifier une conformité, ne cite pas de règle fiscale, taux, délai ou article de loi non inclus dans l’entrée, n’invente pas de faits, et ne propose jamais une écriture comptable chiffrée. Recommande une vérification humaine des pièces et des règles applicables à l’exercice. Rappelle que les résultats sont indicatifs.",
        },
        {
          role: "user",
          content: JSON.stringify(input),
        },
      ],
    });

    const content = result.choices[0]?.message.content;
    if (!content) {
      req.log.warn("Audit AI returned an empty result");
      res.status(503).json({ error: "L’analyse IA n’a pas produit de résultat exploitable." });
      return;
    }

    let decoded: unknown;
    try {
      decoded = JSON.parse(content);
    } catch {
      req.log.warn("Audit AI returned invalid JSON");
      res.status(503).json({ error: "La réponse IA n’a pas pu être validée." });
      return;
    }

    const response = ReviewAuditWithAiResponse.safeParse(decoded);
    if (!response.success) {
      req.log.warn(
        { validationError: response.error.message },
        "Audit AI response failed validation",
      );
      res.status(503).json({ error: "La réponse IA n’a pas pu être validée." });
      return;
    }

    res.json(response.data);
  } catch (error) {
    req.log.error(
      { error: error instanceof Error ? error.message : "Unknown AI provider error" },
      "Audit AI review failed",
    );
    res.status(503).json({
      error: "Le service IA est temporairement indisponible. Réessayez plus tard.",
    });
  }
});

export default router;
